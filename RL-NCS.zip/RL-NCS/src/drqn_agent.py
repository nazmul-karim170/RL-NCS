from src.agent import BaseAgent
from src.history import History
from src.replay_memory import DRQNReplayMemory
from src.networks.drqn import DRQN
import numpy as np
from tqdm import tqdm
import tensorflow as tf
import time
import matplotlib as plt

## We understood the LSTM part, how do we connect CNN part here(!!!).. on ething could be that when we start from LSTM block we have
## to execute all the previous steps up to LSTM. 


class DRQNAgent(BaseAgent):
    def __init__(self, config):
        super(DRQNAgent,self).__init__(config)
        self.replay_memory  = DRQNReplayMemory(config)                # For Replay Memory
        self.net = DRQN(self.env_wrapper.action_space_n, config)      # call the DRQN method 
        self.net.build()                                              # Build the graph for parameters initialization, also calculation of reward and loss functions
        self.net.add_summary(["average_reward", "average_loss", "average_q", "ep_max_reward", "ep_min_reward", "ep_num_game", "learning_rate"], ["ep_rewards", "ep_actions", "ep_ANCS", "ep_reg", "ep_ANCS_ROI", "ep_reg_ROI"])
        self.seq_length = config.seq_length
        self.decrement_game = 3*config.epsilon_decay_episodes                              ## to balance out the randomness of LSTM prediction at the beginning
        self.num_layers = config.num_lstm_layers


    def observe(self, t):
        # Get the reward from environment and compare it with min_max_reward
        reward = max(self.min_reward, min(self.max_reward, self.env_wrapper.reward))    ## where is min_reward, max_reward(class BaseAgent) 
        # It is basically the state(input to the agent)
        self.screen = self.env_wrapper.screen

        # For train_start(=20000) step, stack the experience 
        self.replay_memory.add(self.screen, reward ,self.env_wrapper.action, self.env_wrapper.terminal, t)

        # Decrement of epsilon for e-greedy policy
        if self.i < self.config.epsilon_decay_episodes:
            self.epsilon -= self.config.epsilon_decay

        # check the training_frequency and number of steps to pass for the training to start
        if self.i % self.config.train_freq == 0 and self.i > self.config.train_start:  
            
            ## Sample minibatch from the replay memory
            states, action, reward, terminal = self.replay_memory.sample_batch() 
            
            ## Train the network 
            q, loss = self.net.train_on_batch_target(states, action, reward, terminal , self.i)
            self.total_q += q
            self.total_loss += loss
            self.update_count += 1

        ## After the number of "config.update_freq" steps, update the target network(!!!)
        if self.i % self.config.update_freq == 0:
            self.net.update_target()


    def policy(self,state):
        self.random = False 

        ## According to e-greedy policy
        if np.random.rand() < self.epsilon:
            self.random = True 
            return self.env_wrapper.random_step()

        ## First, we don't trust our neural network system. so, we do the exploration first with random policy. 
        ## After thousand of episodes of training, we do the exploitation. We deacy our epsilon over "confoig.epsilon_decay_episode" episodes.
        else:
            a, self.lstm_state_c, self.lstm_state_h = self.net.sess.run([self.net.q_action, self.net.state_output_c, self.net.state_output_h],
                {
                    self.net.state: [state]-self.lstm_state_h[self.num_layers-1].T,
                    self.net.init_state_train: np.stack([self.lstm_state_c, self.lstm_state_h], axis = 1)
                })
            return a[0]


    def train(self, steps):
        render = False                                          # render is for visualizing the condition of the environment 
        self.env_wrapper.new_random_game()                      # start a new random game
        num_game, self.update_count, ep_reward = 0, 0, 0        # initialize all variables at the start of the episode/game
        total_reward, self.total_loss, self.total_q = 0. , 0. , 0.
        reward, ANCS_errors, reg_errors, ANCS_error, reg_error = 0, 0, 0, 0, 0
        ANCS_errors_ROI, reg_errors_ROI, ANCS_error_ROI, reg_error_ROI = 0, 0, 0, 0
        ## For total rewards in a episode
        ep_rewards, actions = [], []

        ##Count for timestep
        t = 0

        ## Get the state for agent to process
        self.screen = self.env_wrapper.screen  
        
        ## initialize lstm cell state and hidden state
        self.lstm_state_c, self.lstm_state_h = self.net.initial_zero_state_single, self.net.initial_zero_state_single


        ## Whole training process (storing experiences -->  then training)
        ## we initialized "self.i" in BaseAgent class
        try:
            for self.i in tqdm(range(self.i, steps)):

                ## Get the observation from environment 
                state = self.screen
                #print("EVERY STEPP")


                # Use policy to get the action
                action = self.policy(state)

                if self.i <10000:
                	action =1

                # Use action to get the reward and next state
                self.env_wrapper.act(action, t, self.lstm_state_h[self.num_layers-1])  



                # At first, we do the exploration(thats why self.random)
                if self.random:
                    ## Neural Network Part(the "[]"" adds an extra dimension at axis = 0)
                    self.lstm_state_c, self.lstm_state_h = self.net.sess.run([self.net.state_output_c, self.net.state_output_h], {
                        self.net.state: [state] -self.lstm_state_h[self.num_layers-1].T,
                        self.net.init_state_train: np.stack([self.lstm_state_c,self.lstm_state_h], axis = 1 )
                    })
                    
                ## Storing the experience and then training(if certain number of steps has been executed)
                self.observe(t)

                reward_1 = max(self.min_reward, min(self.max_reward, self.env_wrapper.reward))

                if self.env_wrapper.action == 0:    
                    reward_1 -= 0.5

                # If we reach at the end of episodes
                if self.env_wrapper.terminal:              
                    t = 0
                    self.env_wrapper.terminal = False
                    # self.env_wrapper.new_random_game()     # we choose a random start for new episode
                    self.screen = self.env_wrapper.screen  
                    num_game += 1                          # This is the number of episode
                    ep_rewards.append(ep_reward)           # Store the total episode reward
                    ANCS_errors += self.env_wrapper.ANCS_err
                    reg_errors += self.env_wrapper.reg_err
                    ANCS_errors_ROI += self.env_wrapper.ANCS_err_ROI
                    reg_errors_ROI += self.env_wrapper.reg_err_ROI
                    ep_reward = 0.                         # Initialization for new episode
                    self.lstm_state_c, self.lstm_state_h = self.lstm_state_c, self.lstm_state_h

                else:
                    ep_reward += reward_1
                    t += 1


                actions.append(action)
                total_reward += reward_1
                # print("total_reward",total_reward)

                ## ###Finalize the graph  ######
                
                #tf.get_default_graph().finalize() 


                if self.i >= self.config.train_start:

                    ## Condition for summarizing all the feedbacks from agent and environment during training
                    if self.i % self.config.test_step == self.config.test_step - 1:   
                        avg_reward = total_reward / self.config.test_step
                        avg_loss = self.total_loss / self.update_count
                        avg_q = self.total_q / self.update_count

                        print("The avergae RL_LSTM error", ANCS_errors/10)
                        print("The avergae Uniform CS  ", reg_errors/10)
                        print("The avergae RL_LSTM error(ROI)", ANCS_errors_ROI/10)
                        print("The avergae reg_err(Non_ROI)", reg_errors_ROI/10)

                        try:
                            max_ep_reward = np.max(ep_rewards)
                            min_ep_reward = np.min(ep_rewards)
                            avg_ep_reward = np.mean(ep_rewards)
                            ANCS_error = np.mean(ANCS_errors)
                            reg_error = np.mean(reg_errors)
                            ANCS_error_ROI = np.mean(ANCS_errors_ROI)
                            reg_error_ROI = np.mean(reg_errors_ROI)

                        except:
                            max_ep_reward , min_ep_reward, avg_ep_reward, ANCS_error, reg_error = 0, 0, 0, 0, 0

                        sum_dict = {
                            'average_reward': avg_reward,
                            'average_loss': avg_loss,
                            'average_q': avg_q,
                            'ep_max_reward': max_ep_reward,
                            'ep_min_reward': min_ep_reward,
                            'ep_num_game': num_game,
                            'learning_rate': self.net.learning_rate,
                            'ep_rewards': ep_rewards,
                            'ep_actions': actions,
                            'ep_ANCS': ANCS_error,
                            'ep_reg': reg_error,
                            'ep_ANCS_ROI': ANCS_error_ROI,
                            'ep_reg_ROI': reg_error_ROI  
                        }
                        #print(avg_reward, ep_rewards)
                        self.net.inject_summary(sum_dict, self.i)

                        ## Wiping out the dictionary of feedbacks after summarizing and storing them
                        num_game = 0
                        total_reward = 0.
                        self.total_loss = 0.
                        self.total_q = 0.
                        self.update_count = 0
                        ep_reward = 0.
                        ep_rewards = []
                        actions = []
                        ANCS_error_ROI, reg_error_ROI = 0, 0
                        ANCS_error, reg_error = 0, 0
                        ANCS_errors =0
                        reg_errors = 0
                        ANCS_errors_ROI, reg_errors_ROI= 0, 0


                if (self.i+1) % 100 == 0 and self.i > 0:
                    j= 0
                    self.save()


                    ## For Visualization purpose(we can ignore it)
                    #if self.i % 100 == 0:
                    #    j = 0
                    #   render = True


                    #if render:
                    #    self.env_wrapper.env.render()       
                    #    j += 1 
                    #    if j == 10:
                    #        render = False
        except KeyboardInterrupt:
            self.net.close_session()


    ## This is mainly for testing purpose(!!!!!!)
    def play(self, episodes, net_path):
        self.net.restore_session(path = net_path)
        self.env_wrapper.new_game()
        self.lstm_state_c, self.lstm_state_h = self.net.initial_zero_state_single, self.net.initial_zero_state_single
        i = 0
        epsiode_steps = 0
        while i < epsiodes:
            a, self.lstm_state_c, self.lstm_state_h = self.net.sess.run([self.net.q_action, self.net.state_output_c, self.net.state_output_h],
                {
                    self.net.state: [self.env_wrapper.screen]-self.lstm_state_h,
                    self.net.init_state_train: np.stack([self.lstm_state_c,self.lstm_state_h], axis = 1)
            })

            ## Taking the 1st action (maybe sorted max to min)
            action = a[0]    

            # For testing
            self.env_wrapper.act_play(action, episode_steps, self.lstm_state_h[1]) 


            # Counting the steps in an episode
            epsiodes_steps += 1

            if episode_steps > self.config.max_steps:  ## criterion for reaching the terminal
                self.env_wrapper.terminal = True
                
            if self.env_wrapper.terminal:
                epsiode_steps = 0
                i += 1
                self.env_wrapper.new_play_game()
                self.lstm_state_c, slef.lstm_state_h = self.net.initial_zero_state_single, self.net.initial_zero_state_single
