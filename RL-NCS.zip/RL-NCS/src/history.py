import numpy as np
import os

class History:

    def __init__(self, config):
        self.batch_size = config.batch_size
        self.history_len = config.history_len
        self.seq_length = config.seq_length
        self.history = np.zeros((self.history_len, self.seq_length,1), dtype=np.uint8)

    def add(self, screen):
        self.history[:-1] = self.history[1:]
        self.history[-1] = screen

    def reset(self):
        self.history *= 0

    def get(self):
        return self.history
