#import matlab.engine
import tensorflow as tf
from numpy import inf
import numpy as np
import cvxpy as cp 
import cvxpy.atoms.norm as norm
import shutil
from scipy import spatial
from sklearn.linear_model import OrthogonalMatchingPursuit, OrthogonalMatchingPursuitCV
from sklearn.preprocessing import normalize
import time
import warnings
from numpy import array 
warnings.filterwarnings("ignore")

#flatten = tf.keras.layers.Flatten


## we need to use best reconstruction algorithm and get the next state
#Option-1 
#   Install pymatlab and integrate it into matlab path.
##  PyMatlab---->> https://pypi.org/project/pymatlab

#Option-2
##   Install matlab engine(so far, the best way)


class CS_gym():

    def __init__(self, config):                                          
        self.action_space_n = 2
        self.cor_factor = 3                 # How many coefficients would we consider for distributing the energy(action-2)    
        self.seq_length = config.seq_length 

        self.episode_length = config.max_steps

        ##### ## Signal Generator Parameters #### #### ###
        self.SNR = 20
        self.n_samples, self.n_features, self.sparse_index = 60, self.seq_length, 10

        self.alpha = 0.5        # on paper its (ro(p))
        self.sigma_L = 5
        self.sigma_s = 0
        self.p01 = 0.2
        self.sparsity_level = self.sparse_index/self.n_features
        self.zeta = 0
        self.Basis = np.identity(self.n_features)
        self.p10 = (self.sparsity_level*self.p01)/(1 - self.sparsity_level)
        self.caution_value = 0.0001

        ## ### ### Initialize all variables(Reinforcement learning side) ###   ####
        self.lstm_state =  np.random.randn(self.seq_length,1)
        self.predicted_state = np.random.randn(self.seq_length,1)
        self.prev_state = np.random.randn(self.seq_length,1)
        self.shape_supp = np.zeros(self.episode_length+1, dtype=np.int32)
        self.lstm_loss = 0
        self.wt_time = 2
          

    def action_space(self, action, lstm):

        self.action = action

        ## Caution for all zero components
        
        lstm = self.sigmoid(lstm)


        #print("The softmax of LSTM output is", np.shape(lstm))

        #self.lstm_state =  np.absolute(np.transpose(lstm))/max(np.absolute(np.transpose(lstm)))
        #self.predicted_state = np.absolute(self.predicted_state)/max(np.absolute(self.predicted_state))
        self.lstm_state = np.reshape(lstm, (self.seq_length, 1))
        #self.lstm_state = [max(0,v) for i,v in enumerate(self.lstm_state)]

        if action == 0:
            # ind = [i for i,v in enumerate(self.predicted_state) if v > self.caution_value]
            # self.predicted_state[ind] = 1
            # ind_lstm_1 = [i for i,v in enumerate(self.predicted_state) if v <= self.caution_value]
            # self.predicted_state[ind_lstm_1] = 0.3
            self.prev_state = self.sigmoid(self.predicted_state)

        elif action == 1:
        	# ind = [i for i,v in enumerate(self.lstm_state) if 0.8< v <=1]
        	# self.lstm_state[ind] = 0.1
        	# ind_lstm_1 = [i for i,v in enumerate(self.lstm_state) if v <= 0.8]
        	# self.lstm_state[ind_lstm_1] = 0.1
        	self.prev_state = self.lstm_state
            # print("LSTM Action ONeeeeeeeeeeeeee.................***********")

        #print("The original agent", np.shape(self.prev_state))

        if np.all(self.prev_state ==0):
            self.prev_state = self.sigmoid(self.prev_state)

        return self.prev_state 
    
    

    def step(self, action, t, lstm):

        ### #### START of INITIALIZATION ###### ######
        ## If we start a new epsiode, we start from a new point
        if t == 0:
            sig_coef = np.zeros((self.episode_length+1, self.n_features))
            theta_true = np.zeros((self.episode_length+1, self.n_features))
            self.X_true = np.zeros((self.episode_length+1, self.n_features))
            Small_coef = np.random.normal(0, self.sigma_s, (self.n_features))
            Act , Inact ={}, {}
            self.support = {}
            if self.sparse_index == 0:
                self.sparse_index = 2
            inds = np.arange(self.n_features)
            np.random.shuffle(inds)
            sig_coef[0][inds[0:self.sparse_index]] = 1
            self.support[0] = inds[0:self.sparse_index]
            self.shape_supp[0] = np.shape(self.support[0])[0]
            theta_true_1=theta_true[0] =  self.zeta* np.ones((self.n_features)) + np.random.normal(0, self.sigma_L, (self.n_features))
            X_true_1 = self.X_true[0] = sig_coef[0]*theta_true[0]
            #print("The initial shape>>>>>>>>>>>>>>>>,<<,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,", self.shape_supp[0])
            self.error_ANCS = np.zeros(self.episode_length)
            self.error_reg = np.zeros(self.episode_length)
            self.reward_1 = np.zeros(self.episode_length)
            self.len_2 = np.zeros(self.episode_length)
            for i in range(1, self.episode_length):
                Inact = np.where(sig_coef[i-1] == 0)         # indices of inactive(zero) coefficients of previous sequence
                sig_coef[i][Inact] = np.random.rand(np.shape(Inact)[1]) < self.p10
                Act = np.where(sig_coef[i-1] == 1)           # Active Coefficients
                sig_coef[i][Act] = 1 - (np.random.rand(np.shape(Act)[1]) < self.p01)
                self.support[i] =  np.where(sig_coef[i] == 1)
                self.shape_supp[i] = np.shape(self.support[i])[1]
                theta_true_1 = ((1-self.alpha)*(theta_true_1-self.zeta*np.ones((self.n_features)))+ self.alpha * np.random.normal(0, self.sigma_L, self.n_features)) + self.zeta*np.ones((self.n_features))
                theta_true[i] = theta_true_1
                X_true_1 = sig_coef[i]*theta_true[i] + Small_coef
                X_true_1 = np.dot(self.Basis, X_true_1)
                self.X_true[i] = X_true_1
                #print("the Support",i,self.X_true[i-1])
                #print("HELLO  ,,,,,,,", self.X_true[i])

                if np.all(self.X_true[i]==0):
                    self.X_true[i] = self.X_true[i-1]                             # Don't take more than one, coz the first signal[i-1] could be all zero
                    self.shape_supp[i] = self.shape_supp[i-1]
                    self.support[i] = self.support[i-1]
                    print("HI there>>>>>>>>>>>>>>>>>,<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<....................................................")
                ## make the support still for self.wt_time steps
                # for j in range(self.wt_time):
                #     self.X_true[i+j] = self.X_true[i]
                #     sig_coef[i+j] = sig_coef[i]

                #     # print("the Support", self.support[i-self.wt_time+j])
                #     self.shape_supp[i+j] =self.shape_supp[i]


        ## ### ## ## END of INITIALIZATION  #####  ######   #####   ###
        # print("New Episode>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", t)

        ## Get the support according to the action
        self.prev_state = self.action_space(action, lstm)
        self.prev_state[self.support[t]]=1

        ## Distribute energy to the column
        p = np.sqrt(self.n_features/4)*normalize(self.prev_state.reshape(-1,1), norm='l2', axis = 0)
        # p = self.prev_state*5
        Phi = np.random.randn(self.n_samples, self.n_features)
        Phi = np.dot(Phi, np.diag(p.flatten()))
        Phi = normalize(Phi, norm = 'l2',  axis = 0)


        Phi_reg = np.random.normal(0, 2, (self.n_samples, self.n_features))
        Phi_reg = normalize(Phi_reg, norm = 'l2',  axis = 0)


        ##Generate Sparse Signal (with same mean and variance) for every iteration
        X = self.X_true[t]  
        # print("The Signal", X)
  
        ## Measuremest Vector with added noise
        # sig_power = sum(np.power(X, 2))/self.n_samples
        # sigma_noise =np.sqrt(sig_power*10**(-self.SNR/10))
        z1 = np.dot(Phi, X)
        yvar = np.mean(np.abs(z1)**2)
        sigma_noise = yvar*np.power(10, -0.1*self.SNR)
        Y =  z1 + np.random.normal(0, sigma_noise, self.n_samples)

        z2 = np.dot(Phi_reg, X)
        y_var = np.mean(np.abs(z2)**2)
        sigma_noise = y_var*np.power(10, -0.1*self.SNR)        
        Y_reg = np.dot(Phi_reg, X) + np.random.normal(0, sigma_noise, self.n_samples)


        # print("the Measurement", Phi)
        #print("the Measurement matrix", self.shape_supp[t])
        if self.shape_supp[t] == 0:
            self.shape_supp[t] = 2

        # est0_off = vp.estim.DiscreteEst(0,1,zshape0)
        # est0_on   = vp.estim.GaussEst(z0_mean_on, z0_var_on,zshape0)



        #### Orthogonal Matching Pursuit
        omp = OrthogonalMatchingPursuit(n_nonzero_coefs=self.shape_supp[t])
        omp.fit(np.float64(Phi), np.float64(Y))
        X_pred = omp.coef_

        omp_reg = OrthogonalMatchingPursuit(n_nonzero_coefs=self.shape_supp[t])
        omp_reg.fit(np.float64(Phi_reg), np.float64(Y_reg))
        X_recon = omp_reg.coef_


        MIC = np.zeros(self.seq_length)
        MIC[self.support[t]] = 1
        # print("The regular",MIC)
        # print("THE ANCS", self.predicted_state)

        ## Calculate the TMNSE error
        self.error_ANCS[t] = sum(MIC*np.square(X - X_pred))/sum(MIC*X**2)
        self.error_reg[t] = sum(np.square(X - X_recon))/sum(X**2)
        # print("The ANCS error", self.error_ANCS[t])


        ### Process the reconstructed signal
        self.predicted_state = 0.1 * np.ones((self.seq_length, 1))
        self.predicted_state[self.support[t]] = 10
        
        #self.predicted_state = abs(self.predicted_state)


        #print("The Predicted:", self.predicted_state)

        ## #### CREDIT ASSIGNMENT (change min_reward and max_reward in agent.py) #### #### ###

        # indices_1 = self.support.get(t)[0]
        # #len_1 = (indices_1)
        # if t==0:
        #     indices_1 = self.support.get(t)
        # np.reshape(lstm, (self.seq_length))
        # self.prev_state /= max(self.prev_state)
        
        indices_1 = [i for i,v in enumerate(self.predicted_state) if abs(v)==5]
        indices = [i for i,v in enumerate(np.squeeze(self.prev_state)) if v==1]
        ind = [i for i,v in enumerate(np.squeeze(self.prev_state)) if  v<0.6]
        # indices = np.squeeze(lstm).argsort()[-25:][::-1]
        len_1 = len(indices_1)
        self.len_2[t] = len(ind)

        # print("The orginal agent prediction", len(indices))
        # print("The Original Signal Support is ", self.prev_state[indices_1])
        # print("The next predicted thing", len(ind))


        prev_state = np.zeros(len_1)
        pred_state = np.ones(len_1)


        # print("The predicted one", len_1)
        
        for i in range(len_1):
            for j in range(len(indices)):
                if indices[j]==indices_1[i]:
                    prev_state[i] = 1

        ## Design it in terms of precision and recall 
        if len(indices) == 0:
            indices = [1]

        if len_1==0:
            len_1  = 1

        precision = sum(prev_state==1)/len(indices)    #min_reward=-1, max_reward=1
        recall = sum(prev_state==1)/len_1

        
        reward = recall
        self.reward_1[t] = reward



        ##   DESIGN IT in terms of F1 SCORE

        # F1_score = 2*precision*recall/(precision+recall)     #min_reward=-0.5, max_reward=0.5
        # reward = F1_score-1


        ## Calculate the HAMMING DISTANCE(We can set the reward as the negative of ham_err too)
        # if action == 1:
        #     self.lstm_loss = spatial.distance.hamming(pred_state,prev_state)
        # else:
        #     self.lstm_loss = 0

        #reward =np.float16(0.5-ham_err)

        # print("The Reward is", reward)





        # At the end of the episode
        if t == self.max_steps-1:
            self.terminal = True
            self.ANCS_error = np.mean(self.error_ANCS)
            self.reg_error = np.mean(self.error_reg)
            # print("The avergae length", np.mean(self.len_2))
            # print("The average reward is", np.mean(self.reward_1))

            # print("HI>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>LLLLLl")

        return self.predicted_state, reward, self.terminal 
     
    ## For Visualization Purpose
    def render(self):
        print("The Running state is: %f", self.predicted_state)


    def reset(self):
        self.terminal = False
        self.reward = 0

        ## At the start of the episode, we can have random values for our sates
        self.predicted_state = abs(2*np.random.randn(self.seq_length,1))
        self.action = 0


    def sigmoid(self, z):
        return 1/(1+ np.exp(-z))




