from tensorflow.python.client import device_lib

def get_available_gpus():
    local_device_protos = device_lib.list_local_devices()
    return [x.name for x in local_device_protos if x.device_type == 'GPU']

class Config(object):

    train_steps = 10000000         # Training steps(5 million)
    batch_size = 8
    history_len = 4            # Past history of actions, rewards, states (This is for DQN)
    frame_skip = 4             # Especially for DRQN(see the paper)
    epsilon_start = 1.0        # Epsilon greedy policy(starting point)
    
    epsilon_end = 0.01        # ending point for policy choice
    max_steps = 100          # number of steps for manually terminating the episode
    epsilon_decay_episodes = 5000  # Exploration-Expoitation criterion.
    train_freq = 1             # After this number of samples train agarin
    update_freq = max_steps        # update the parameters at each cycle of this number of steps   
    train_start = 11            # start the training procedure after this number of steps
    dir_save = "saved_session_new/"  # change this for every new simulation run
    restore = False
    epsilon_decay = float((epsilon_start - epsilon_end))/float(epsilon_decay_episodes)
    random_start = 1           # It's like number of times we want to do the refreshing in a computer
    test_step = 10* max_steps           # number of steps after which we want to re-evaluate the feedbacks from environment and agent
    network_type = "drqn"


    gamma = 0.1              # calculating Q-value and target value for predicted Q-value
    learning_rate_minimum = 0.00025
    lr_method = "sgd"         # Learning method
    learning_rate = 0.05     
    lr_decay = 0.97           # learning rate decay(if we do not use minimum learning rate)
    alpha_decay =0.9
    # keep_prob = 0.8         # For the dropout layer
    alpha_loss = 1


    num_lstm_layers = 2   
    keep_prob = 1
    lstm_size = 200           # LSTM layer size (same as sequence length)
    min_history = 1        # minimum number of sates required to predict the next state
    states_to_update =1     # Number of future states to update


    # FOR GPU uses
    if get_available_gpus():
        cnn_format = "NWC"
    else:
        cnn_format = "NWC"



class CSConfig(Config):
    state = None
    seq_length = 200 
    env_name = "CS_ENV"
    ## For replaying the experiences
    mem_size = 500000

