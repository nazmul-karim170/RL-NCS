#import matlab.engine
import tensorflow as tf
from numpy import inf
import numpy as np
import cvxpy as cp 
import cvxpy.atoms.norm as norm
import shutil
from scipy import spatial
from sklearn.linear_model import OrthogonalMatchingPursuit, OrthogonalMatchingPursuitCV
from sklearn.preprocessing import normalize
import time
import warnings
from numpy import array 
from scipy.fftpack import ifft, idct, dct
from numpy import linalg as LA

warnings.filterwarnings("ignore")

#flatten = tf.keras.layers.Flatten


## we need to use best reconstruction algorithm and get the next state
#Option-1 
#   Install pymatlab and integrate it into matlab path.
##  PyMatlab---->> https://pypi.org/project/pymatlab

#Option-2
##   Install matlab engine(so far, the best way)


class CS_gym():

    def __init__(self, config):                                          
        self.action_space_n = 2
        self.cor_factor = 1                 # How many coefficients would we consider for distributing the energy(action-2)    
        self.seq_length = config.seq_length 

        self.episode_length = config.max_steps

        ##### ## Signal Generator Parameters #### #### ###
        self.SNR = 20
        self.n_samples, self.n_features, self.sparse_index = 10, self.seq_length, 20

        self.alpha = 0.2       # on paper its (ro(p))
        self.sigma_L = 5
        self.sigma_s = 0.01
        self.p01 = 0.02
        self.fault_rate =   0.5    ## Difference between fault_rate and transition probability
        self.sparsity_level = self.sparse_index/self.n_features
        self.zeta = 0
        self.DCT_basis = dct(np.identity(self.n_features), type =2)
        self.DCT_basis= normalize(self.DCT_basis , norm = 'l2',  axis = 0)

        self.basis = np.identity(self.n_features)
        # self.DCT_basis  = self.basis
        # self.DCT_basis = dct(self.Basis, type = 2)


        self.p10 = (self.sparsity_level*self.p01)/(1 - self.sparsity_level)
        self.caution_value = 0.0001

        ## ### ### Initialize all variables(Reinforcement learning side) ###   ####
        self.lstm_state =  np.random.randn(self.seq_length,1)
        self.predicted_state = np.ones((self.seq_length,1))
        self.prev_state = np.ones((self.seq_length,1))
        self.shape_supp = np.zeros(self.episode_length+1, dtype=np.int32)
        self.lstm_loss = 0
        self.wt_time = 2
          

    def action_space(self, action, lstm):

        self.action = action

        ## Caution for all zero components
        
        lstm = self.sigmoid(lstm)


        #print("The softmax of LSTM output is", np.shape(lstm))

        #self.lstm_state =  np.absolute(np.transpose(lstm))/max(np.absolute(np.transpose(lstm)))
        #self.predicted_state = np.absolute(self.predicted_state)/max(np.absolute(self.predicted_state))
        self.lstm_state = np.reshape(lstm, (self.seq_length, 1))
        # print("The LSTM ouput", self.lstm_state)
        #self.lstm_state = [max(0,v) for i,v in enumerate(self.lstm_state)]

        ## First Action
        if action == 0:
            ind = [i for i,v in enumerate(self.predicted_state) if v == 1]
            # print("The length of support", len(ind))
            # ind_1 = np.random.shuffle(ind)
            # ind_keep= np.int32((1-self.p01)*len(ind)) 
            # # print("The length", ind_keep)
            self.prev_state[ind] = 0.9
            ind_lstm_1 = [i for i,v in enumerate(self.predicted_state) if v < 1]
            # ind_2 = np.random.shuffle(ind_lstm_1)
            # ind_add= np.int32(self.p01*len(ind)) 
            # # print("The length", ind_add)
            self.prev_state[ind_lstm_1] = 0.1
            # self.prev_state[ind_lstm_1[ind_add]:ind_lstm_1[-1]] = 0.2 
            # self.prev_state = self.sigmoid(self.predicted_state)

        ## LSTM Action
        elif action == 1:
            ind = [i for i,v in enumerate(self.predicted_state) if v == 1]
            self.lstm_state[ind] = 0.9
            ind_lstm = [i for i,v in enumerate(self.lstm_state) if v >= 0.7]
            self.lstm_state[ind_lstm] = 0.9
            ind_lstm_1 = [i for i,v in enumerate(self.lstm_state) if v <= 0.5]
            self.lstm_state[ind_lstm_1] = 0.1
            self.prev_state = self.lstm_state
            # print("LSTM Action ONeeeeeeeeeeeeee.................***********")
        
        # # ## Distribute the energy
        # elif action == 2: 
        #     ind = [i for i,v in enumerate(self.predicted_state) if v == 1 ]
        #     ind_out = [i for i,v in enumerate(self.predicted_state) if v < 1]
        #     self.prev_state[ind_out] = 0.2
        #     # value_ind = np.zeros(2*len(ind),1)
            
        #     # if len(ind) == 0:
        #     #     ind[0] =1
        #     # print("The Index", ind)
        #     for i in range(len(ind)):
        #         if ind[i] != self.seq_length-1:
        #             self.prev_state[ind[i]] = self.prev_state[ind[i]+1] = sum(self.predicted_state[ind[i]:ind[i]+1])/np.sqrt(2)
        #         else:
                    # self.prev_state[ind[i]] = 0.77


            # value_ind = [sum(self.predicted_state[i:i-self.cor_factor])/np.sqrt(2) for i in ind[1:]]
            # self.prev_state[ind[1:]] = np.reshape(value_ind, (len(value_ind),1))
            

        # elif action == 1:
        #     ind_lstm = [i for i,v in enumerate(self.lstm_state) if 0.05<v<0.4]
        #     self.lstm_state[ind_lstm] =1
        #     self.lstm_state[self.lstm_state<=0.05]=0.4

        #     self.prev_state = self.lstm_state
        #     print("LSTM Action Twoooooo.................***********", ind_lstm)


        # shuffle the indices of lstm output
        # elif self.action == 4:
        #     ind = [i for i,v in enumerate(self.lstm_state) if v > self.caution_value]
        #     #print("Fifth:",len(ind))
        #     np.random.shuffle(ind)
        #     ind1 = np.random.choice(self.seq_length,round(len(ind)/2),replace=False)
        #     self.lstm_state[ind1] = self.lstm_state[ind[0:round(len(ind)/2)]]
        #     self.lstm_state[ind[0:round(len(ind)/3)]] = self.caution_value
        #     self.prev_state = self.lstm_state
        #     #print("Fifth Action", self.prev_state)


        # ## shuffle the indices of the previous support
        # elif self.action == 5:
        #     ind = [i for i,v in enumerate(self.predicted_state) if v> self.caution_value]
        #     np.random.shuffle(ind)
        #     #print("Sixth:",len(ind))
        #     ind1 = np.random.choice(self.seq_length,round(len(ind)/2),replace=False)
        #     self.predicted_state[ind1] = self.predicted_state[ind[0:round(len(ind)/2)]]
        #     self.predicted_state[ind[0:round(len(ind)/3)]] = self.caution_value
        #     self.prev_state = self.predicted_state
            #print("sixth Action", self.prev_state)

        # print("The original agent", self.prev_state)

        if np.all(self.prev_state ==0):
            self.prev_state = self.sigmoid(self.prev_state)

        return self.prev_state 
    
    

    def step(self, action, t, lstm):

        ### #### START of INITIALIZATION ###### ######
        ## If we start a new epsiode, we start from a new point
        if t == 0:
            sig_coef = np.zeros((self.episode_length, self.n_features))
            roi_coef = np.zeros((self.episode_length, self.n_features))
            theta_true = np.zeros((self.episode_length, self.n_features))
            self.X_true = np.zeros((self.episode_length, self.n_features))
            self.sparse_signal = np.zeros((self.episode_length, self.n_features))
            Small_coef = np.random.normal(0, self.sigma_s, (self.n_features))

            Act , Inact ={}, {}
            Act_roi, Inact_roi = {}, {}
            self.support = {}
            self.ROI_signal = {}

            if self.sparse_index == 0:
                self.sparse_index = 2
            inds = np.arange(self.n_features)
            np.random.shuffle(inds)
            
            # For variation in Support
            sig_coef[0][inds[0:self.sparse_index]] = 1
            self.support[0] = inds[0:self.sparse_index]

            # For variation in ROI
            np.random.shuffle(inds)
            roi_coef[0][inds[0:self.sparse_index]] = 1

            self.ROI_signal[0] = inds[0:self.sparse_index]
            self.shape_supp[0] = np.shape(self.support[0])[0]
            theta_true_1=theta_true[0] =  self.zeta* np.ones((self.n_features)) + np.random.normal(0, self.sigma_L, (self.n_features))
            X_true_1 = self.X_true[0] = sig_coef[0]*theta_true[0]

            self.error_ANCS = np.zeros(self.episode_length)
            self.error_reg = np.zeros(self.episode_length)
            self.error_ANCS_ROI = np.zeros(self.episode_length)
            self.error_Non_ROI = np.zeros(self.episode_length)
            self.reward_1 = np.zeros(self.episode_length)
            self.len_2 = np.zeros(self.episode_length)
            self.count = 0


            for i in range(1,self.episode_length):
                ### For Correlation between "Support"
                Inact = np.where(sig_coef[i-1] == 0)         # indices of inactive(zero) coefficients of previous sequence
                sig_coef[i][Inact] = np.random.rand(np.shape(Inact)[1]) < self.p10
                Act = np.where(sig_coef[i-1] == 1)           # Active Coefficients
                sig_coef[i][Act] = 1 - (np.random.rand(np.shape(Act)[1]) < self.p01)
                self.support[i] =  np.where(sig_coef[i] == 1)

                ### FOR correlation between "ROI"
                Inact_roi = np.where(roi_coef[i-1] == 0)         # indices of inactive(zero) coefficients of previous sequence
                roi_coef[i][Inact_roi] = np.random.rand(np.shape(Inact_roi)[1]) < self.p10
                Act_roi = np.where(roi_coef[i-1] == 1)           # Active Coefficients
                roi_coef[i][Act_roi] = 1 - (np.random.rand(np.shape(Act_roi)[1]) < self.p01)
                self.ROI_signal[i] =  np.where(roi_coef[i] == 1)
                # print("The ROI of the signal", self.ROI_signal[i])


                self.shape_supp[i] = np.shape(self.support[i])[1]
                theta_true_1 = ((1-self.alpha)*(theta_true_1-self.zeta*np.ones((self.n_features)))+ self.alpha * np.random.normal(0, self.sigma_L, self.n_features)) + self.zeta*np.ones((self.n_features))
                theta_true[i] = theta_true_1
                X_true_DCT= sig_coef[i]*theta_true[i] + (1-sig_coef[i])*Small_coef

                self.sparse_signal[i] = np.dot(self.basis, X_true_DCT)
                
                ## Normalize DCT matrix
                
                X_true_original = np.dot(self.DCT_basis.T, X_true_DCT)             # This is "u", self.DCT_basis is a real orthonormal matrix.
                self.X_true[i] = X_true_original

                #print("the Support",i,self.X_true[i-1])
                #print("HELLO  ,,,,,,,", self.X_true[i])

                if np.all(self.X_true[i]==0):
                    self.X_true[i] = self.X_true[i-1]                             # Don't take more than one, coz the first signal[i-1] could be all zero
                    self.shape_supp[i] = self.shape_supp[i-1]
            # print("HI there>>>>>>>>>>>>>>>>>,<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<....................................................")
                         ## make the support still for self.wt_time steps
                # for j in range(self.wt_time):
                #     self.X_true[i+j] = self.X_true[i]
                #     sig_coef[i+j] = sig_coef[i]

                #     # print("the Support", self.support[i-self.wt_time+j])
                #     self.shape_supp[i+j] =self.shape_supp[i]


        ## ### ## ## END of INITIALIZATION  #####  ######   #####   ###
        # print(self.predicted_state)
        # print('The support is', self.support[t])
        # print('The ROI is', self.ROI_signal[t])

        ## Get the support according to the action
        self.prev_state = self.action_space(action, lstm)




        # print("New Episode>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", t)
        # self.DCT_basis= normalize(self.DCT_basis , norm = 'l2',  axis = 0)

        ## For 1st reconstruction, the estimated support should be same as original support
        if t == 0: 
            self.n_samples = 120
        else:
            self.n_samples = 60


                      ### Distribute energy to the column ###
        p = np.sqrt(self.n_features)*normalize(self.prev_state.reshape(-1,1), norm='l2', axis = 0)
        Phi = np.random.randn(self.n_samples, self.n_features)
        Phi = normalize(Phi, norm = 'l2',  axis = 0)
        Phi = np.dot(Phi, np.diag(p.flatten()))

                       # With Bernuolli ###
        #Phi = np.array([np.random.binomial(1, p, self.n_samples) for p in self.prev_state]).T
        # Phi = normalize(Phi, norm = 'l2',  axis = 0)
        

        # print(Phi)
        # Phi = Phi.T


        Phi_reg = np.random.randn(self.n_samples, self.n_features)
        Phi_reg = normalize(Phi_reg, norm = 'l2',  axis = 0)


        ##Generate Sparse Signal (with same mean and variance) for every iteration
        X = self.X_true[t]  
        # print("the Signal", X)

        if np.all(X == 0):
            X = np.random.normal(0, self.sigma_L, self.n_features)

        U = self.sparse_signal[t]
        # print("The original Signal>>>>>.>>>>>.", U[self.ROI_signal[t]])
        # print("The Signal", LA.norm(Phi_reg))
  
        ## Measuremest Vector with added noise
        # sig_power = sum(np.power(X, 2))/self.n_samples
        # sigma_noise =np.sqrt(sig_power*10**(-self.SNR/10))
        z1 = np.dot(Phi, X)
        yvar = sum(np.square(z1))
        sigma_noise = np.sqrt(yvar*np.power(10, -0.1*self.SNR))
        Y =  np.dot(Phi, X)+ np.random.normal(0, sigma_noise, self.n_samples)

        # print("The Signal>>>>", z1)

        # print("The Measurement>>>>", Y)
        
        z2 = np.dot(Phi_reg, X)
        y_var = sum(np.square(z1))
        sigma_noise_uni = np.sqrt(y_var*np.power(10, -0.1*self.SNR))        
        Y_reg = np.dot(Phi_reg, X) + np.random.normal(0, sigma_noise, self.n_samples)

        if self.shape_supp[t] == 0:
            self.shape_supp[t] = 2

        #### Orthogonal Matching Pursuit
        # omp = OrthogonalMatchingPursuit(n_nonzero_coefs=self.shape_supp[t])
        # omp.fit(np.float64(Phi), np.float64(Y))
        # X_pred = omp.coef_

        # omp_reg = OrthogonalMatchingPursuit(n_nonzero_coefs=self.shape_supp[t])
        # omp_reg.fit(np.float64(Phi_reg), np.float64(Y_reg))
        # X_recon = omp_reg.coef_



        # print("The ANCS error", self.error_ANCS[t])




        # #### Using Matlab Engine ###### ######### ######
        # eng = matlab.engine.start_matlab()
        # eng.cd(r'/home/nazmul/DRQN_tensorflow/Code_CISS', nargout=0)
        # Y, Phi = eng.Environment_RL(matlab.double(list(tf.Session().run(tf.reshape(self.prev_state, [-1])))), nargout=2)

        ## L1-minimization--Construct the problem.
        Y = np.reshape(Y, (-1,1))
        x = cp.Variable((self.seq_length,1))
        objective = cp.Minimize(norm(x,1))

        constraints = [norm(Y - np.matmul(Phi, self.DCT_basis.T)*x)<=sigma_noise/np.sqrt(self.n_samples)]
        # constraints = [norm(Y - Phi*x)<=np.sqrt(sigma_noise/self.n_samples)]
        prob = cp.Problem(objective, constraints)

        # print("the DCT matrix", self.DCT_basis)


        # The optimal objective value is returned by `prob.solve()`.
        try:
            prob.solve(verbose = False)
        except:
            prob.solve(solver = "SCS", verbose = False)
       

        ## Optimizer gives None value when the Phi Matrix is too sparse.
        if x.value is not None:
            U_pred = np.squeeze(np.float32(x.value))
        else:
            U_pred = np.random.randn(self.seq_length)
            print("Found A None value")

        Y_reg=  np.reshape(Y_reg, (-1,1))
        x_reg = cp.Variable((self.seq_length,1))
        objective = cp.Minimize(norm(x_reg,1))
        constraints = [norm(Y_reg - np.matmul(Phi_reg,self.DCT_basis.T)*x_reg)<=sigma_noise_uni/np.sqrt(self.n_samples)]
        # constraints = [norm(Y_reg - Phi_reg*x_reg)<=np.sqrt(sigma_noise/self.n_samples)]
        prob = cp.Problem(objective, constraints)

        # The optimal objective value is returned by `prob.solve()`.
        try:
            prob.solve(verbose = False)
        except:
            prob.solve(solver="SCS", verbose = False)
        

        ## Optimizer gives None value when the Phi Matrix is too sparse.
        if x_reg.value is not None:
            U_recon = np.squeeze(np.float32(x_reg.value))
        else:
            U_recon = np.random.randn(self.seq_length)
            print("Found A None value for Uniform")



        ### Most Important Coefficients and Least Important Coefficients indices 
        MIC = np.zeros(self.seq_length)
        MIC[self.ROI_signal[t]] = 1
        
        ## ROI coefiicients and Non-ROI coefficients for reconstruction error
        MIC_ROI = MIC
        indices_MIC = [i for i,v in enumerate(MIC) if v == 1]
        # non_ROI = np.zeros(self.seq_length)
        # non_ROI[indices_non_ROI] = 1  

        # print("the before>>>>", self.ROI_signal[t])

        ## Change the ROI based on fault_rate
        # indices_MIC = self.ROI_signal[t]
        len_ROI = len(indices_MIC)

        indices_LIC= [i for i,v in enumerate(MIC) if v == 0]
        

        num_of_flips = np.int32(self.fault_rate * len_ROI)
        indices_all= [i for i in range(self.n_features)]
        np.random.shuffle(indices_MIC)
        np.random.shuffle(indices_LIC)
        # print("the previous", num_of_flips)
        # print("the MIC >>>>", indices_MIC[0:num_of_flips])
        MIC[indices_LIC[0:num_of_flips]] = 1 
        MIC[indices_MIC[0:num_of_flips]] = 0


        # print("the pppe", MIC)
        indices_MIC_1= [i for i,v in enumerate(MIC) if v == 1]


        # print("The ROI" , U_pred)
        # MIC_ROI[indices_non_ROI] = 1             ###### (ASK ALIREZA)

        # print(sum(np.square(non_ROI*(abs(X) - abs(X_pred)))))
        # print("The signal",np.shape(X[self.ROI_signal[t]]))
        ## Calculate the TMNSE error
        X_pred =np.dot(self.DCT_basis.T, U_pred)
        # print("the Predicted >>>>>>>>>>>", np.shape(X_pred[self.ROI_signal[t]]))
        X_recon = np.dot(self.DCT_basis.T, U_recon)
        # print("The reconstruction" , X_recon[self.ROI_signal[t]])
        # print("the signal", sum(X[self.ROI_signal[t]]**2))
        # print("the Predicted >>>>>>>>>>>", np.shape(np.square((X[self.ROI_signal[t]] - X_pred[self.ROI_signal[t]]))))
        # print("the reconstruction>::::::::::::", sum(np.square((X[self.ROI_signal[t]] - X_recon[self.ROI_signal[t]]))))
        if len_ROI == 0:
            print(t)
            # X[self.ROI_signal[t]]**2 = 3

        # print("the next >>>>>> >>>>>>", np.shape(MIC*(X - X_pred)))
        self.error_ANCS_ROI[t] = sum(np.square((X[self.ROI_signal[t]] - X_pred[self.ROI_signal[t]])))/sum(X[self.ROI_signal[t]]**2)
        
        self.error_Non_ROI[t] = sum(np.square((X[indices_LIC] - X_pred[indices_LIC])))/sum(X[indices_LIC]**2)
        
        self.error_ANCS[t] = sum(np.square(X - X_pred))/sum(X**2)
        
        self.error_reg[t] = sum(np.square(X - X_recon))/sum(X**2)


        # print("The length0", len(indices_MIC))
        if self.error_ANCS_ROI[t] > 1.5:
            self.count += 1
            self.error_ANCS_ROI[t] = 1


        ## ### State for the Agent ### ###
        self.predicted_state= MIC
        # print("the Predicted >>>>>>>>>>>", self.error_ANCS_ROI[t])
        # print("the uniform>::::::::::::", self.error_reg[t])

                   ## For sparse signal in canonical basis ###
        # X_pred = U_pred
        # X_recon = U_recon
        # # indices_LIC = [i for i,v in enumerate(abs(X_pred)) if v<0.2]
        # MIC = np.zeros(self.seq_length)
        # MIC[self.support[t]] = 1
        # indices_LIC= [i for i,v in enumerate(MIC) if v == 0]
        # indices_MIC= [i for i,v in enumerate(MIC) if v == 1]


        # self.error_ANCS_ROI[t] = sum(MIC*np.square((X - X_pred)))/sum(MIC*X**2)
        
        # self.error_Non_ROI[t] = sum(np.square((X[indices_LIC] - X_pred[indices_LIC])))
        
        # self.error_ANCS[t] = sum(np.square(X - X_pred))/sum(X**2)
        
        # self.error_reg[t] = sum(np.square(X - X_recon))/sum(X**2)
        
        # # print("The after ::: : :: ::", X_pred)
        # # # print("The error is:", self.error_reg[t], self.error_ANCS[t], self.error_ANCS_ROI[t])

        # # print(" The support", indices_MIC)
        # # print(" The LIC", indices_LIC)
        # indices_pred = [i for i,v in enumerate(abs(X_pred)) if v>0.2]
        # # indices = [i for i,v in enumerate(np.squeeze(X_pred)) if abs(v)]
        # ### Process the reconstructed signal

        # # self.predicted_state = np.reshape(self.predicted_state, (self.seq_length, 1))
        # #self.predicted_state[self.predicted_state==0] = 0.01

        
        # #self.predicted_state = abs(self.predicted_state)
        # self.predicted_state = np.zeros((self.seq_length,1)
        # self.predicted_state[indices_pred] = 1

      

        ## #### CREDIT ASSIGNMENT (change min_reward and max_reward in agent.py) #### #### ###

        # indices_1 = self.support.get(t)[0]
        # #len_1 = (indices_1)
        # if t==0:
        #     indices_1 = self.support.get(t)
        # np.reshape(lstm, (self.seq_length))
        # self.prev_state /= max(self.prev_state)
        
        indices_1 = [i for i,v in enumerate(self.predicted_state) if abs(v)==1]
        if action==2:
            indices = [i for i,v in enumerate(np.squeeze(self.prev_state)) if v >= 0.5]
        else:
            indices = [i for i,v in enumerate(np.squeeze(self.prev_state)) if v==1]
        # indices =indices_pred
        ind = [i for i,v in enumerate(np.squeeze(self.prev_state)) if  v<0.6]
        # indices = np.squeeze(lstm).argsort()[-25:][::-1]
        len_1 = len(indices_1)
        self.len_2[t] = len(indices)

        # print("The orginal agent prediction", indices)
        # print("The Original Signal Support is ", indices_1)
        # print("The next predicted thing", len(ind))


        prev_state = np.zeros(len_1)
        pred_state = np.ones(len_1)


        # print("The predicted one", len_1)
        
        for i in range(len_1):
            for j in range(len(indices)):
                if indices[j]==indices_1[i]:
                    prev_state[i] = 1

        ## Design it in terms of precision and recall 
        if len(indices) == 0:
            indices = [1]

        if len_1==0:
            len_1  = 1

        precision = sum(prev_state==1)/len(indices)    #min_reward=-1, max_reward=1
        recall = sum(prev_state==1)/len_1

        
        reward =  2*recall
        self.reward_1[t] = reward



        ##   DESIGN IT in terms of F1 SCORE

        # F1_score = 2*precision*recall/(precision+recall)     #min_reward=-0.5, max_reward=0.5
        # reward = F1_score-1


        ## Calculate the HAMMING DISTANCE(We can set the reward as the negative of ham_err too)
        # if action == 1:
        #     self.lstm_loss = spatial.distance.hamming(pred_state,prev_state)
        # else:
        #     self.lstm_loss = 0

        #reward =np.float16(0.5-ham_err)

        # print("The Reward is", reward)


        # At the end of the episode
        if t == self.max_steps-1:
            self.terminal = True

            self.ANCS_error = np.mean(self.error_ANCS)
            self.reg_error = np.mean(self.error_reg)
            self.ANCS_error_ROI = np.mean(self.error_ANCS_ROI)
            self.reg_error_ROI = np.mean(self.error_Non_ROI)

            print("Average RL-LSTM", self.ANCS_error)
            print("Average error Non-ROI", self.reg_error_ROI)
            print("The average error ROI", self.ANCS_error_ROI)
            print("The average Uniform CS", self.reg_error)
            print("The overstep", self.count)
            # print("HI>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>LLLLLl")

        return self.predicted_state, reward, self.terminal 
     
    ## For Visualization Purpose
    def render(self):
        print("The Running state is: %f", self.predicted_state)


    def reset(self):
        self.terminal = False
        self.reward = 0

        ## At the start of the episode, we can have random values for our sates
        self.predicted_state = abs(2*np.random.randn(self.seq_length,1))
        self.action = 0


    def sigmoid(self, z):
        return 1/(1+ np.exp(-z))




