import numpy as np
import random
import os

class ReplayMemory:
    def __init__(self, config):
        self.config = config
        self.actions = np.empty((self.config.mem_size), dtype = np.int32)
        self.rewards = np.empty((self.config.mem_size), dtype = np.float32)
        self.screens = np.empty((self.config.mem_size, self.config.seq_length, 1), dtype = np.float16)
        self.terminals = np.empty((self.config.mem_size), dtype = np.float16)      ## what is it(???)
        self.count = 0
        self.current = 0
        self.dir_save = config.dir_save + "memory/"

        if not os.path.exists(self.dir_save):
            os.makedirs(self.dir_save)


    ## For Saving the experiences
    def save(self):
        np.save(self.dir_save + "screens.npy", self.screens)
        np.save(self.dir_save + "actions.npy", self.actions)
        np.save(self.dir_save + "rewards.npy", self.rewards)
        np.save(self.dir_save + "terminals.npy", self.terminals)
    
    # For loading the experiences and results
    def load(self):
        self.screens = np.load(self.dir_save + "screens.npy")
        self.actions = np.load(self.dir_save + "actions.npy")
        self.rewards = np.load(self.dir_save + "rewards.npy")
        self.terminals = np.load(self.dir_save + "terminals.npy")





class DQNReplayMemory(ReplayMemory):

    # screen: only one input to the network
    # self.screens: batch of inputs to the network

    def __init__(self, config):
        super(DQNReplayMemory, self).__init__(config)
        self.pre = np.empty((self.config.batch_size, self.config.history_len, self.config.seq_length,1), dtype = np.uint8)
        self.post = np.empty((self.config.batch_size, self.config.history_len, self.config.seq_length,1), dtype = np.uint8)
        

    def getState(self, index):

        index = index % self.count
        if index >= self.config.history_len-1:
            a = self.screens[(index - (self.config.history_len - 1)):(index+1)]
            return a

        else:
            indices = [(index-i) % self.count for i in reversed(range(self.config.history_len))]
            return self.screens[indices]

    def add(self, screen, reward, action, terminal):

        assert screen.shape == (self.config.seq_length,1)

        self.actions[self.current] = action
        self.rewards[self.current] = reward
        self.screens[self.current] = screen
        self.terminals[self.current] = float(terminal)


        ## Keeping the count of experiences 
        self.count = max(self.count, self.current + 1)    

                
        self.current = (self.current + 1) % self.config.mem_size    


    def sample_batch(self):
        assert self.count > self.config.history_len

        indices = []
        while len(indices) < self.config.batch_size:
            while True:
                index = random.randint(self.config.history_len, self.count - 1)

                if index >= self.current and index - self.config.history_len < self.current:
                    continue

                if self.terminals[(index - self.config.history_len): index].any():
                    continue
                break
            self.pre[len(indices)] = self.getState(index - 1)
            self.post[len(indices)] = self.getState(index)
            indices.append(index)

        actions = self.actions[indices]
        rewards = self.rewards[indices]
        terminals = self.terminals[indices]

        return self.pre, actions , rewards, self.post, terminals

class DRQNReplayMemory(ReplayMemory):

    def __init__(self, config):
        super(DRQNReplayMemory, self).__init__(config)


        ## How many timesteps we have passed 
        self.timesteps = np.empty((self.config.mem_size), dtype = np.int32)    

        ## For your information about experiences     
        self.states = np.empty((self.config.batch_size,self.config.min_history + self.config.states_to_update + 1, self.config.seq_length, 1), dtype = np.uint8)
        self.actions_out = np.empty((self.config.batch_size, self.config.min_history + self.config.states_to_update + 1))
        self.rewards_out = np.empty((self.config.batch_size, self.config.min_history + self.config.states_to_update + 1), dtype = np.float16)
        self.terminals_out = np.empty((self.config.batch_size, self.config.min_history + self.config.states_to_update + 1))

    def add(self, screen, reward, action, terminal, t):


        assert screen.shape == (self.config.seq_length,1)
 
        self.actions[self.current] = action
        self.rewards[self.current] = reward
        self.screens[self.current] = screen
        self.timesteps[self.current] = t
        self.terminals[self.current] = float(terminal)

        # Keeping the count of experiences 
        self.count = max(self.count, self.current + 1)   

        ## Reset when replay memory is full               
        self.current = (self.current + 1) % self.config.mem_size        


    ## For getting all the states for past min_history number of timesteps
    def getState(self, index):
        a = self.screens[index -  (self.config.min_history + self.config.states_to_update + 1): index]
        return a


    ## For fetching the corresponding actions and rewards to states
    def get_scalars(self, index):
        t = self.terminals[index - (self.config.min_history + self.config.states_to_update + 1) : index]
        a = self.actions[index - (self.config.min_history + self.config.states_to_update + 1): index]
        r = self.rewards[index - (self.config.min_history + self.config.states_to_update + 1): index]
        return a, t, r

    ## Sampling the experiences with a size of "config.batch_size"
    def sample_batch(self):

        ## making sure we get the minimum number of experiences we need 
        assert self.count > self.config.min_history + self.config.states_to_update

        indices = []


        ## Until we get full batch of experiences, We choose a index first , then take previous (min_history + states_to_update) samples. Then we choose a new index again. 
        ## Total(batch_size* (min_history + states_to_update)) samples.  
        while len(indices) < self.config.batch_size:

            while True:
                ## I am not convinced by this(Lets see during training)
                index = random.randint(self.config.min_history, self.count - 1)
                if index >= self.current and index - self.config.min_history < self.current:
                    continue
                if index < self.config.min_history + self.config.states_to_update + 1:
                    continue
                if self.timesteps[index] < self.config.min_history + self.config.states_to_update:
                    continue

                break

            ## Get one of the state from experiences     
            self.states[len(indices)] = self.getState(index)

            # Get the corresponding actions and rewards
            self.actions_out[len(indices)], self.terminals_out[len(indices)], self.rewards_out[len(indices)] = self.get_scalars(index)
            indices.append(index)

        return self.states, self.actions_out, self.rewards_out, self.terminals_out