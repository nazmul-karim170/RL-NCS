import numpy as np
from src.Environment import CS_gym

class CSWrapper(CS_gym):

    def __init__(self, config):
        super(CSWrapper,self).__init__(config)
        #self.env = CS_gym                                    #import the CS environment here 
        self.seq_length = config.seq_length
        self.reward = 0
        self.terminal = False                                ## are we done for this episode( we put true because there are fixed number of steps for each episode)
        self.frameskip = config.frame_skip                   # what is frame skip
        self.random_start = config.random_start
        self.action_space = self.action_space
        self._screen = np.empty(self.seq_length, dtype=np.float16)
        self.lstm = np.absolute(2*np.random.randn(self.seq_length,1))
        self.max_steps = config.max_steps
        self.ANCS_err, self.reg_err = 0 , 0
        

    def new_game(self):
        self.reset()
        self._step(0,0, self.lstm)
        self.reward = 0
        self.action = 0
    
    ## if we want to start a random game (which is not necessary)
    def new_random_game(self):
        
        ## It is same as new game(just a matter of assurance to be random)
        self.new_game()
        
        ## Upto "random_start" number of refreshing at the start of the new game
        #for _ in range(np.random.randint(0, self.random_start)):
        #    self._step(0, 0, self.lstm)


    def _step(self, action, t, lstm):
        self.action = action
        self.screen1, self.reward, self.terminal = self.step(action, t, lstm)
        if self.terminal ==True:
            self.ANCS_err, self.reg_err, self.ANCS_err_ROI, self.reg_err_ROI = self.ANCS_error, self.reg_error, self.ANCS_error_ROI, self.reg_error_ROI


    def random_step(self):
        return np.random.randint(self.action_space_n)

    def act(self, action, t, lstm):
        self.lstm = lstm
        self._step(action, t, self.lstm)


    def act_play(self, action):
        self._step(action,0, self.lstm,0)
        self.render()


    def new_play_game(self):
        self.new_game()
        self._step(1,0, self.lstm, 1)


    @property
    def screen(self):
        a = np.reshape(self.screen1 ,(self.seq_length,1))
        return a


