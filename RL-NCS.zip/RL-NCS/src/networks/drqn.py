import numpy as np
import os
import tensorflow as tf
import shutil
from functools import reduce
from tensorflow.python import debug as tf_debug
from src.utils import conv1d_layer, fully_connected_layer, stateful_lstm, huber_loss, hamming_loss
from src.networks.base import BaseModel
import time
from numpy import array


class DRQN(BaseModel):
    
    def __init__(self, n_actions, config):
        super(DRQN, self).__init__(config, "drqn")
        self.n_actions = n_actions                        # number of actions for reinforcement learning
        self.cnn_format = config.cnn_format               # CNN format  
        self.num_lstm_layers = config.num_lstm_layers     # number of LSTM cell with [num_lstm_layers] 
        self.lstm_size = config.lstm_size                 # size of the LSTM output 
        self.min_history = config.min_history             # minimum number of steps to be executed before training start
        self.states_to_update = config.states_to_update   # number of states to be updated after executing min_num_steps(min_history)(!!!!!)
        self.keep_prob = config.keep_prob
        self.alpha_loss = config.alpha_loss
        self.alpha_decay = config.alpha_decay


        
    def add_placeholders(self):
        
        ## For storing the weights of convolution layers
        self.w = {}
        self.w_target = {}
        

        ### Placeholder for state, action, reward
        self.state = tf.placeholder(tf.float32, shape = [None, self.seq_length, 1 ], name = "input_state" )
        self.pred = tf.placeholder(tf.float32, shape = [None, self.seq_length], name = "lstm_pred" )
        self.mask = tf.placeholder(tf.float32, shape = [None, self.seq_length], name = "Mask_lstm" )
        self.next_state = tf.placeholder(tf.float32, shape = [None, self.seq_length], name = "next_state" )

        
        self.action = tf.placeholder(tf.int32, shape = [None], name = "action_input")
        self.reward = tf.placeholder(tf.int32, shape = [None], name = "reward")
        self.state_target = tf.placeholder(tf.float32, shape = [None, self.seq_length, 1], name = "input_target")
        
        
        ### Create placeholder to fill in lstm state
        self.init_state_train = tf.placeholder(tf.float32, [self.num_lstm_layers, 2, None, self.lstm_size], name ="train_states")
        self.state_per_layer_list_train = tf.unstack(self.init_state_train, axis = 0)
        self.lstm_state_train = tuple([tf.nn.rnn_cell.LSTMStateTuple(self.state_per_layer_list_train[idx][0], self.state_per_layer_list_train[idx][1]) 
                                        for idx in range(self.num_lstm_layers)]) 

        self.init_state_target = tf.placeholder(tf.float32, [self.num_lstm_layers, 2, None, self.lstm_size], name ="target_states")
        self.state_per_layer_list_target = tf.unstack(self.init_state_target, axis = 0)
        self.lstm_state_target = tuple([tf.nn.rnn_cell.LSTMStateTuple(self.state_per_layer_list_target[idx][0], self.state_per_layer_list_target[idx][1]) 
                                        for idx in range(self.num_lstm_layers)]) 

        ### Initial zero sate to be used when starting episode 
        self.initial_zero_state_batch = np.zeros((self.num_lstm_layers, self.batch_size, self.lstm_size), dtype=np.float32)
        self.initial_zero_state_single = np.zeros((self.num_lstm_layers,1, self.lstm_size))
        
        self.initial_zero_complete = np.zeros((self.num_lstm_layers, 2, self.batch_size, self.lstm_size), dtype = np.float32)
        
        self.dropout = tf.placeholder(dtype = tf.float32, shape =[], name = "dropout")
        self.lr = tf.placeholder(dtype = tf.float32, shape = [], name ="lr")
        
        self.target_val = tf.placeholder(dtype=tf.float32, shape=[None], name="target_val")
        self.terminal = tf.placeholder(dtype=tf.float32, shape=[None], name="terminal")
        self.target_val_tf = tf.placeholder(dtype=tf.float32, shape=[None, self.n_actions])

        self.reward_loss = tf.placeholder(tf.float32, shape=[None])
        
        #self.lstm_output = tf.placeholder(tf.float32, shape = [None , self.seq_length], name ="pred_state")
        #self.pred_state = tf.placeholder(tf.float32, shape = [None , self.seq_length, 1], name ="lstm_output")

        
    def add_logits_op_train(self):
        
        if self.cnn_format == "NCW":
            x = tf.transpose(self.state, [0, 2, 1])
        else:
            out = x = self.state
            
        self.image_summary = []
        w, b, x, summary = conv1d_layer(x, 12, 5, 2, scope_name="conv1_train",
                                          summary_tag="conv1_out",
                                          activation=tf.nn.relu, data_format=self.cnn_format)
        self.w["wc1"] = w
        self.w["bc1"] = b
        self.image_summary.append(summary)

        # w, b, out, summary = conv1d_layer(out, 18, 4, 2, scope_name="conv2_train", summary_tag="conv2_out",
        #                                   activation=tf.nn.tanh, data_format=self.cnn_format)
        # self.w["wc2"] = w
        # self.w["bc2"] = b
        # self.image_summary.append(summary)

        # w, b, out, summary = conv1d_layer(out, 24, 3, 1, scope_name="conv3_train", summary_tag="conv3_out",
        #                                   activation=tf.nn.tanh, data_format=self.cnn_format)
        # self.w["wc3"] = w
        # self.w["bc3"] = b
        #self.image_summary.append(summary)

        shape = x.get_shape().as_list()

        ## Reshaping it as (batch_size * max_time-steps * features)
        ## In this case we are taking just only one time_step 

        out_flat = tf.reshape(x, [tf.shape(x)[0], 1, shape[1] * shape[2]])
        
        out, state = stateful_lstm(out_flat, self.num_lstm_layers, self.lstm_size, self.lstm_state_train, self.keep_prob,
                                               scope_name="lstm_train")

        self.state_output_c = [state[idx][0] for idx in range(self.num_lstm_layers)]
        self.state_output_h = [state[idx][1] for idx in range(self.num_lstm_layers)]

        self.pred = self.state_output_h[self.num_lstm_layers-1] #, self.mask)

        shape = x.get_shape().as_list()
        out = tf.reshape(x, [tf.shape(x)[0], shape[1] *shape[2]])       # we could use tf.squeeze(out,axis = 1) 
        
        w, b, out = fully_connected_layer(out, 32, scope_name="out_train_1", activation=tf.nn.elu)

        self.w["wout1"] = w
        self.w["bout1"] = b

        w, b, out = fully_connected_layer(out, self.n_actions, scope_name="out_train_2", activation=tf.nn.softmax)

        self.w["wout2"] = w
        self.w["bout2"] = b

        self.q_out = out
        self.q_action = tf.argmax(self.q_out, axis=1)
        
        
    def add_logits_op_target(self):
        
        if self.cnn_format == "NCW":
            x = tf.transpose(self.state_target, [0, 2, 1])
        else:
            out = x = self.state_target

        w, b, x, _ = conv1d_layer(x, 12, 5, 2, scope_name="conv1_target", summary_tag=None,
                                    activation=tf.nn.tanh, data_format=self.cnn_format)
        self.w_target["wc1"] = w
        self.w_target["bc1"] = b

        # w, b, out, _ = conv1d_layer(out,18, 4, 2, scope_name="conv2_target", summary_tag=None,
        #                             activation=tf.nn.tanh, data_format=self.cnn_format)
        # self.w_target["wc2"] = w
        # self.w_target["bc2"] = b

        # w, b, out, _ = conv1d_layer(out, 24, 3, 1, scope_name="conv3_target", summary_tag=None,
        #                             activation=tf.nn.tanh, data_format=self.cnn_format)
        # self.w_target["wc3"] = w
        # self.w_target["bc3"] = b

        # shape = out.get_shape().as_list()

        # out_flat = tf.reshape(out, [tf.shape(out)[0], 1, shape[1] * shape[2] ])
        # out, state = stateful_lstm(out_flat, self.num_lstm_layers, self.lstm_size,
        #                                               self.lstm_state_target, self.keep_prob, scope_name="lstm_target")


        # ## We are taking state because it contains the information at the last timesteps of our input sequence
        # self.state_output_target_c = [state[idx][0] for idx in range(self.num_lstm_layers)]
        # self.state_output_target_h = [state[idx][1] for idx in range(self.num_lstm_layers)]


        shape = x.get_shape().as_list()

        out = tf.reshape(x, [tf.shape(x)[0], shape[1] * shape[2]])

        w, b, out = fully_connected_layer(out, 32, scope_name="out_target_1", activation=tf.nn.elu)

        self.w_target["wout1"] = w
        self.w_target["bout1"] = b

        w, b, out = fully_connected_layer(out, self.n_actions, scope_name="out_target_2", activation=tf.nn.softmax)

        self.w_target["wout2"] = w
        self.w_target["bout2"] = b

        self.q_target_out = out
        # print(self.q_target_out.get_shape())
        self.q_target_action = tf.argmax(self.q_target_out, axis=1)
        
    
    def train_on_batch_target(self, states, action , reward, terminal, steps):
        
                ## Until we get full batch of experiences, We choose a index first , then take previous (min_history + states_to_update) samples. Then we choose a new index again. 
        ## Total(batch_size* (min_history + states_to_update)) samples.  

        ### #### ## We have (batch_size* (min_history + states_to_update)) samples, But we use #min_history of samples to update the next #states_to_update samples. 
                 ## So, total #batch_size*states_to_update samples gets updated. If #states_to_update is less than #min_history, ur system is realiable and it will take time (with a order of #min_history/#states_to_update) to train.  

        ## Initialize Q-value, action, reward and Loss
        q, loss = np.zeros((self.batch_size, self.n_actions)), 0
        states = np.transpose(states, [1, 0, 2, 3])
        action = np.transpose(action, [1,0])             ## Transposing to make batch_size as the axis = 1, we need total min_history+states_to_update number of values
        reward = np.transpose(reward, [1,0])
        terminal = np.transpose(terminal, [1,0])
        #print("The actions are", action)


        ## Reshaping the input for training purposes
        states = np.reshape(states, [states.shape[0], states.shape[1], states.shape[2], 1])

        ## Initialize lstm cell sates(from previous cell) and history states for 1st iteration
        lstm_state_c, lstm_state_h = self.initial_zero_state_batch, self.initial_zero_state_batch

        ## Get the target cell and history (from previous cell) for LSTM network for 1st iteration
        # lstm_state_target_c, lstm_state_target_h = self.sess.run(
        #     [self.state_output_target_c, self.state_output_target_h],
        #     {
        #         self.state_target: states[0],
        #         self.init_state_target: self.initial_zero_complete

        #     }
        # )

        ## Get the cell and history (for the prior cells) for entire min_history(num_of steps)
        for i in range(self.min_history):
            j = i + 1
            lstm_state_c, lstm_state_h = self.sess.run(
                [self.state_output_c, self.state_output_h],
                {
                    self.state: states[i]-np.expand_dims(lstm_state_h[self.num_lstm_layers-1], axis=2),
                    # self.state_target: states[j]-np.expand_dims(lstm_state_target_h[self.num_lstm_layers-1], axis=2),
                    # self.init_state_target: np.stack([lstm_state_target_c, lstm_state_target_h], axis = 1),
                    self.init_state_train: np.stack([lstm_state_c,lstm_state_h], axis = 1)
                }
            )

        for i in range(self.min_history, self.min_history + self.states_to_update):
            j = i + 1

            ## Calculate the target value for Q-value and LSTM cell(prior cells of target network)
            target_val = self.sess.run(
                [self.q_target_out],     # we don't update the main networks cell and history (prior cells) 
                {                                                                                # in this setup..because we are going to calculate them through training(!!!)   
                    self.state_target: states[j] #-np.expand_dims(lstm_state_target_h[self.num_lstm_layers-1], axis =2),                                                # Target network just uses the parameters(weights and biases) of main network                                                
                    # self.init_state_target: np.stack([lstm_state_target_c, lstm_state_target_h], axis = 1)
                }
            )

            ## Calculate the target value from the target network
            # print(np.shape(target_val))
            max_target = np.max(np.squeeze(target_val), axis = 1)                                       # get the optimum action
            target = (1.- terminal[i])* self.gamma * max_target + reward[i]
            theta = lstm_state_h[self.num_lstm_layers-1]

            output_Mask = np.zeros((self.batch_size, self.seq_length))
            next_state = np.zeros((self.batch_size, self.seq_length))
            for k in range(self.batch_size):
                for ind in range(self.seq_length):
                    if states[j,k,ind,0]==1:
                        
                        next_state[k,ind] = 1

                    # if states[i,k,ind,0]==1:
                    #     output_Mask[k,ind] = 1
                    # else:
                    #     output_Mask[k,ind] =0.15

                    # if theta[k,ind] > 0.9:
                    #     output_Mask[k,ind] = 1
            # print("The output mask is", output_Mask)

            ## Training phase begins by minimizing loss and calculating Q-value(main network)
            _, q_, train_loss_, lstm_state_c, lstm_state_h, merged_imgs= self.sess.run(
                [self.train_op, self.q_out, self.loss, self.state_output_c, self.state_output_h, self.merged_image_sum],
                feed_dict={
                    self.state: states[i]-np.expand_dims(lstm_state_h[self.num_lstm_layers-1], axis =2),
                    self.init_state_train: np.stack([lstm_state_c,lstm_state_h], axis =1),
                    self.target_val: target,
                    self.lr: self.learning_rate,
                    self.action: action[i],
                    self.next_state: next_state,
                    self.mask: output_Mask
                }
            )
            
            q += q_
            loss += train_loss_

        # print("The overall loss is", loss)

        if self.train_steps % 5000 == 0:                         # change this at the time of training
            self.file_writer.add_summary(merged_imgs, steps)

        if steps % 1000 == 0 and steps > 2000:                 # change this at the time of training
            # self.learning_rate *= self.lr_decay                     ## decay learning rate
            self.alpha_loss *= self.alpha_decay
            if self.learning_rate < self. learning_rate_minimum:
                self.learning_rate = self.learning_rate_minimum

        self.train_steps += 1

        return q.mean(), loss / (self.states_to_update)           ## why using mean for Q-value(!!)



    def add_loss_op_target(self):

        action_one_hot = tf.cast(tf.one_hot(self.action, self.n_actions , 1 , 0, name = 'action_one_hot'), tf.float32)

        # compute the sum of elements across dimension (axis) of a tensor
        train = tf.reduce_sum(self.q_out * action_one_hot, reduction_indices =1 , name = 'q_acted')    

        ## calculate the difference between target value(target network) and max(Q-value)
        self.delta = train - self.target_val 

        #num_action = tf.reduce_sum(tf.cast(tf.equal(self.action,1), tf.float32), axis =0)
        #lstm_loss = tf.reduce_sum(tf.multiply(tf.cast(self.action,tf.float32), (1.-tf.squeeze(self.reward_loss))))/tf.cast(num_action,tf.float32)
        # lstm_loss = tf.reduce_mean(1.-tf.squeeze(self.reward_loss))         

        # compute the mean of elements across dimension (axis) of a tensor
        self.loss = (1-self.alpha_loss)* tf.reduce_mean(huber_loss(self.delta)) + self.alpha_loss* tf.reduce_mean(tf.nn.weighted_cross_entropy_with_logits(self.next_state, self.pred,  pos_weight =5))
        

        ## saving average Q-value(!!!)
        avg_q = tf.reduce_mean(self.q_out, 0)
        q_summary = []
        for i in range(self.n_actions):
            q_summary.append(tf.summary.histogram('q/{}'.format(i), avg_q[i]))

        self.merged_image_sum = tf.summary.merge(q_summary, 'q_summary')
        self.loss_summary = tf.summary.scalar("loss", self.loss)


    ## Build the whole graph 
    def build(self):
        self.add_placeholders()
        self.add_logits_op_train()
        self.add_logits_op_target()
        self.add_loss_op_target()                
        self.add_train_op(self.lr_method, self.lr, self.loss)
        self.initialize_session()
        self.init_update()



    ## update the target network
    def update_target(self):

        for name in self.w:
            self.target_w_assign[name].eval({self.target_w_in[name]: self.w[name].eval(session=self.sess)},
                                                    session = self.sess)
        # for var in self.lstm_vars:
        #     self.sess.run(self.target_w_assign[var.name],{self.target_w_in[var.name]: var.eval(session=self.sess)})


    def init_update(self):

        ## For updating parmaeters of CNN 
        self.target_w_in = {}          # For initialization(memory reserve)
        self.target_w_assign = {}      # For assigning the original values
        for name in self.w:
            self.target_w_in[name] = tf.placeholder(tf.float32, self.w_target[name].get_shape().as_list(), name = name)
            self.target_w_assign[name] = self.w_target[name].assign(self.target_w_in[name])

        # # get the lstm_trainable_variables which has a matching name "lstm_train" and "lstm_traget"
        # self.lstm_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope = "lstm_train")
        # lstm_target_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope = "lstm_target")

        # for i, var in enumerate(self.lstm_vars):
        #     self.target_w_in[var.name] = tf.placeholder(tf.float32, var.get_shape().as_list())   
        #     self.target_w_assign[var.name] = lstm_target_vars[i].assign(self.target_w_in[var.name])

